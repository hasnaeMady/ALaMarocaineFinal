export class Customer {
     Name: string;
     Phonenumber: number;
     home: any;
     Work: any;
     Other: any;
}

//la table customer n'existe pas
