export class Order {
    orderId: number; //order_id 

    chefName: string; //n'existe pas
    platName: string; //n'existe pas
    platDescription: string; //n'esxite pas
    image: string;  //n'existe pas
    totalprice: number; //total_price
    
    orderStatus: string; //order_status
    //address_id
    //order_placed_time
    //user_id
}


//les commentaires sont associés à la table order_details