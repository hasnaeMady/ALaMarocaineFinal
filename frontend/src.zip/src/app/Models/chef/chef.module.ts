import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class ChefModule {
  [x: string]: any;

  chefId: number; //chef_id
  ChefModule: string;//n'existe
  specialite: string;//specialite
  chefName: string; //chef_name
  chefPrenom: string;//chef_prenom
  origine: string; //origine
 // noOfPlats: number;//no_of_plats
  image: string;//image
  createdDateAndTime: Date; //created_date_time
 // status: string;//status
 chefDeSemaine: boolean;

  // updated_date_and_time
  // user_id 

 }

 //les plats associés à la table "plat"










