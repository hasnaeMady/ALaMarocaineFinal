import { PlatsearchpipePipe } from './platsearchpipe.pipe';

describe('PlatsearchpipePipe', () => {
  it('create an instance', () => {
    const pipe = new PlatsearchpipePipe();
    expect(pipe).toBeTruthy();
  });
});
