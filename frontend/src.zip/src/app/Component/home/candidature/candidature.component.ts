import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidature',
  templateUrl: './candidature.component.html',
  styleUrls: ['./candidature.component.scss']
})
export class CandidatureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
