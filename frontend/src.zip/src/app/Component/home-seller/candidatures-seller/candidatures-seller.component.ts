import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidatures-seller',
  templateUrl: './candidatures-seller.component.html',
  styleUrls: ['./candidatures-seller.component.scss']
})
export class CandidaturesSellerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
