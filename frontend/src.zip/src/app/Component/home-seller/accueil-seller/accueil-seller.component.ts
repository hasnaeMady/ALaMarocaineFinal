import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accueil-seller',
  templateUrl: './accueil-seller.component.html',
  styleUrls: ['./accueil-seller.component.scss']
})
export class AccueilSellerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
