import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-seller',
  templateUrl: './home-seller.component.html',
  styleUrls: ['./home-seller.component.scss']
})
export class HomeSellerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
