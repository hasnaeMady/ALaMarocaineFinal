import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accueil-client',
  templateUrl: './accueil-client.component.html',
  styleUrls: ['./accueil-client.component.scss']
})
export class AccueilClientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
